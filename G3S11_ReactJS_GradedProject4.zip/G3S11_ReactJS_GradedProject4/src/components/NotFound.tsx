const NotFound = () => {
    return (<>NotFound 404</>)
}

export default NotFound;