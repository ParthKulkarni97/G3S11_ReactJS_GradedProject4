interface IMovieDetail{

    posterurl: string,
  title: string,
  storyline: string,
  closeModal: any
  }
  
  export default IMovieDetail;