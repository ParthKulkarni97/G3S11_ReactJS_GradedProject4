// interface IMovieObjKeys {
//     k1: string,
//     k2: string,
//     k3: string,
//     k4: string,
//     k5: string
// }

// const KeyObj:IMovieObjKeys = {
//     k1:"movies-coming",
//     k2:"movies-in-theaters",
//     k3:"top-rated-india",
//     k4:"top-rated-movies",
//     k5:"favourites"
// }

// // export default KeyObj;
export {};